var options= '';
var pinnedPoint = '';
var str="";

function suggest() {
    var location = document.getElementById("location").value;
    if(location!=str){
    var resultDiv = document.getElementById("result");
    try {
        Gp.Services.autoComplete({
            text: location,
            apiKey: "rhr7qw2f1nz7irqkk63pxxrk",
            onSuccess: function(result) {
                var resultStr= ""

                if (result.suggestedLocations) {
                    for (i=0 ; i<result.suggestedLocations.length; i++) {
                       var loc= result.suggestedLocations[i] ;
                        resultStr+= "<p>" + loc.fullText + "</p>" ;
                        appendToList(loc.fullText);
                    }
                }
            },
            onFailure: function(error) {
                resultDiv.innerHTML = "<p>" + error + "</p>"
            }
        });
    } catch (e) {
        resultDiv.innerHTML = "<p>" + e + "</p>"
}
    }

}

function appendToList(item){
var list = document.getElementById("adresse");
var option = document.createElement('option');
   option.value = item;
   list.appendChild(option);

}

function pinPoint(){

  clearSuggestionList();
   var resultDiv = document.getElementById("result");
  var ad =document.getElementById('location').value;
  str=ad;
  var list = document.getElementById("adresse").innerHTML="";
  if (ad==""){
    alert("Search is empty !!")
  }
  else {
    Gp.Services.geocode ({
    apiKey : "rhr7qw2f1nz7irqkk63pxxrk",
    location : ad,
    // traitement des resultats
    onSuccess  : function (result) {
     pinnedPoint = L.marker([result.locations[0].position.x,result.locations[0].position.y]);
     pinnedPoint.addTo(map);
     map.flyTo([result.locations[0].position.x,result.locations[0].position.y]);
     // map.setView([result.locations[0].position.x,result.locations[0].position.y],12);
    },
    onFailure: function(error) {
              alert("<p>" + ad+'/n'+error + "</p>");
    }
}) ;
  }
  console.log(ad+"hi");

}

function info(){
    console.log("hi--------------------------------------");
}

function clearSuggestionList(){
  var list = document.getElementById("adresse");

  var length = list.options.length;
  for (i = 0; i < length; i++) {
list.options[i] = null;
console.log("here-------------------------------------");
}
}

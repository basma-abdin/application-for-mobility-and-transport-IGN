
 var Lat=0; var Long=0; var process=0;
 var map, maxZoom=0;
 var center;
var watchID;
var markers; var userLoc;
var userIcon = L.icon({
  iconUrl: 'library/leaflet/images/parking.png',
  iconSize: [29, 24],
  iconAnchor: [9, 21],
  popupAnchor: [0, -14]
  });
// var point = L.marker([Lat,Long],{icon: userIcon});
// var point = L.circleMarker([Lat,Long]).setRadius(5);
var userPoint = L.userMarker(location.latlng, {pulsing:true});
userPoint.setAccuracy(10);



document.addEventListener("backbutton", onBackKeyDown, false);
function onBackKeyDown() {
  history.back();
  return false;
}


 (function getPosition() {
    var options = {
       enableHighAccuracy: true,
       maximumAge: 3600000
    }
   watchID = navigator.geolocation.getCurrentPosition(onSuccess, onError, options);
    function onSuccess(position) {
      Lat= position.coords.latitude;
      Long=position.coords.longitude;
      userLoc = L.latLng(position.coords.latitude,position.coords.longitude);
    }
    function onError(error) {
       alert('code: '    + error.code    + '\n' + 'message: ' + error.message + '\n');
   }

  }());

function watchPos(){

     watchID=navigator.geolocation.watchPosition(function(e){
       Lat=e.coords.latitude;Long=e.coords.longitude;
        center = L.latLng(e.coords.latitude, e.coords.longitude);
        userLoc = L.latLng(e.coords.latitude, e.coords.longitude);
        userPoint.setLatLng(center);
   },function(error){  alert('code: '    + error.code    + '\n' + 'message: ' + error.message + '\n');},
   { timeout: 100000 }
 );
}

watchPos();
  Gp.Services.getConfig({
      apiKey : "rhr7qw2f1nz7irqkk63pxxrk",
      onSuccess : go
  }) ;

  function go() {
    var LatCentre=48.87357382650303; var LongCentre=2.2949297501728103;
        if (Lat != 0 || Long != 0 ){
          LatCentre=Lat;
          LongCentre=Long;
        }
       map = L.map('map', {
      center: [LatCentre,LongCentre],
      zoom: 14
  });

  // var map = L.map("map").setView([48.86, 2.35], 12);

      var lyrMaps = L.geoportalLayer.WMTS({
          layer: "GEOGRAPHICALGRIDSYSTEMS.MAPS.BDUNI.J1",
      }, { // leafletParams
          opacity: 2
      });

       var forsearche = L.geoportalLayer.WMTS({
      layer: "GEOGRAPHICALGRIDSYSTEMS.MAPS.SCAN-EXPRESS.STANDARD",
    }, { // leafletParams
      opacity: 0.7
    });
    map.setMinZoom(7);
    map.setMaxZoom(18);
      // var scale =L.control.scale();
      map.addLayer(lyrMaps) ;
      map.addLayer(forsearche) ;


    // map.locate({
    //   watch: true,
    //   locate: true,
    //   setView: true,
    //   enableHighAccuracy: true
    // });

///////////////////////////
var customControl =  L.Control.extend({

  options: {
    position: 'topright'
  },

  onAdd: function (map) {
    var container = L.DomUtil.create('div', 'leaflet-bar leaflet-control leaflet-control-custom');
    container.style.backgroundColor = 'white';
    container.style.backgroundImage = '<img src = "css/img/loc.png"></img>';
    container.style.backgroundSize = "30px 30px";
    container.style.width = '20px';
    container.style.height = '20px';
    container.innerHTML = '<i class="fas fa-location-arrow"></i>'

    container.onclick = locateUser;

    return container;
  }
});
map.addControl(new customControl());
///////////
       var searchCtrl = L.geoportalControl.SearchEngine({});
     // map.addControl(scale);
      if (Lat != 0 || Long != 0 ){
      //   userPoint = L.userMarker([Lat,Long]);
        userPoint.setLatLng([Lat,Long]);

      }

      
      userPoint.addTo(map);
       document.getElementById("info").innerHTML= '<p> laaaaaaat:'+Lat+'long'+Long+'</p>';
        map.on("moveend",handleEvant);
        map.on("zoomend",handleVisibility);
        map.on("move",hideBtn);
        // map.on("locationfound", function(location) {
        //   userPoint.setLatLng(location.latlng);
        //   Lat = location.latlng.lat;
        //   console.log("ggggg "+Lat);
        //   Long = location.latlng.lng;
        //   center = L.latLng(Lat ,Long );
        //   userLoc = L.latLng(Lat ,   Long );
        //   console.log(55);
        //   alert("here");
        //   userPoint.setAccuracy(location.accuracy);
        // });
        // map.on("locationerror", locErr)
  }

  function locateUser(){
    if(userLoc.lat == 0 && userLoc.lng == 0){
      alert('<i class="fas fa-exclamation-triangle"></i> S\'il vous plaît allumer la localisation');
    }
    else map.flyTo([userLoc.lat,userLoc.lng]);
  }

function stopWatchPos(){
  navigator.geolocation.clearWatch(watchID);
}

function handleEvant() {
 if (map.getZoom() >= maxZoom){
  if(process == 1 ){
    c = map.getCenter();
    findParking(c);
  }
  if(process == 2){
    c = map.getCenter();
    findStation(c);
  }
 }
}
$( "fieldset" ).change( handleProcess );


function handleProcess(){
  var choice =$("#e :radio:checked").val();
  if(layerRoute.getLayers().length >0) layerRoute.clearLayers();
  if (choice == "parking") {
      $("#formV").hide();
      process = 1 ;
      document.getElementById("tabletimeDiv").style.display = "none";
      if(cntrlLayerT) {
        // console.log(44+pruneCluster.getLayers().length);
         stationsPoints.RemoveMarkers();
        removeLayer(stationsPoints);
        console.log("h");
        cntrlLayerT = false;
        clearTable();
     }
      // if(pruneCluster.getLayers().length >0) {
      //   console.log(44+pruneCluster.getLayers().length);
      //   pruneCluster.clearLayers();
      //   console.log("h");
      //   clearTable();
      // }
      findParking (center);
  }
  if (choice == "transport"){
    $("#formV").hide();
      process = 2 ;
      document.getElementById("tabletimeDiv").style.display = "initial";
       if (parkingPoints.getLayers().length >0) {
         parkingPoints.clearLayers();
        resultDiv.innerHTML = "";
       }
      findStation(center);
  }
  if (choice == "velo"){
      process = 3
      document.getElementById("tabletimeDiv").style.display = "none";
        $("#formV").show('fade');
  }
  console.log(choice);

}
function handleVisibility() {

    console.log("handleVisibility "+map.getZoom());
//   var lay; var go = false
//     if(process == 1) lay = parkingPoints ;
//     else if (process == 2) lay = stationsPoints ;
//     else go = true;
//     if(!go){
//     if (map.getZoom() <11){
//       console.log("zoom 7");
//        layArr  =  lay.getLayers();
//       for (var i = 0; i < layArr.length; i++) {
//           map.removeLayer(layArr[i]);
//       }
//     }
//     else {
//       console.log("zoom not 7");
//        layArr  =  lay.getLayers();
//       for (var i = 0; i < layArr.length; i++) {
//           map.addLayer(layArr[i]);
//       }
//     }
//   }
}

function locErr() {
  alter("Error when get location");
}



$("#routeDiv").hide();

function hideBtn() {
//  $("#goBtn").hide();
   $("#goBtn").prop("disabled",true);
}

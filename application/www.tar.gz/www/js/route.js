var latDest ; var lngDest;
var type="Pieton"; var mode ;var layerRoute = L.geoJson();
var storeDataR; var tab;

/////////// JQury ///////////////////////
$("#walk").css('color','#007bff');


$("#goBtn").on("click",function() {
    $("#goModal").modal();
});

$("#carC").on("click",function () {
  $(this).css('color','#007bff');
  $("#walk").css("color","inherit");
  type="Voiture";
})

$("#walk").on("click",function () {
   $(this).css('color','#007bff');
  $("#carC").css("color","inherit");
  type="Pieton";
});

$(document).on('pagebeforeshow', '#details', function(){
  console.log("datails page "+storeDataR);
  clear();
  getRouteDetails(storeDataR);

});




////////////////////////////////////////////////////
function toGo(ln , lt) {
  console.log("clickd");
  $("#goBtn").prop("disabled",false);
  document.getElementById("goBtn").innerHTML = "ALLER";
  console.log(ln+" ttt "+lt);

  latDest = lt;
  lngDest = ln;
//  console.log("to go "+e.target.llat + " , "+e.target.llon);
}
function toGoP(e) {
  console.log("clickd");
  $("#goBtn").prop("disabled",false);
  document.getElementById("goBtn").innerHTML = "ALLER";
  // console.log(ln+" ttt "+lt);

  latDest = e.target.llat;
  lngDest = e.target.llon;
//  console.log("to go "+e.target.llat + " , "+e.target.llon);
}

function getGoModalInfo() {
  console.log(userLoc.lat+" , "+userLoc.lng);
    $("#goModal").modal('toggle');
  var userPos; var destLat = latDest ; var destLng = lngDest;
  u = $("#origine").val();
  if(u=="Votre localisation") userPos = userLoc;
  mode = $( "select#mode" ).val();

  console.log("lat "+userPos.lat+"lng " +userPos.lng + "// "+mode + "//" + type+" // " + destLat + " , "+ destLng);
  console.log(destLat+" // "+destLng);
  calcuateRoute(userPos,destLat,destLng,mode,type);
}


function calcuateRoute(userPos,destLat,destLng,mode,type) {
  document.getElementById("goBtn").innerHTML = "MODIFIER";
  if (layerRoute.getLayers().length >0) layerRoute.clearLayers();
  try {
    Gp.Services.route({
      startPoint: {
        x: userPos.lng,
        y: userPos.lat
      },
      endPoint: {
        x:destLng ,
        y: destLat
      },
      graph: type,
      avoidFeature: [],
      routePreference: mode,
      apiKey: "rhr7qw2f1nz7irqkk63pxxrk",
      onSuccess: tracer ,
      onFailure: function(error) {
        resultDiv.innerHTML = "<p>" + error + "</p>";
      }
    });
  } catch (e) {
    resultDiv.innerHTML = "<p>" + e + "</p>"
  }
}

function tracer(result) {
  if(process == 2) document.getElementById("tabletimeDiv").style.display = "none";
  document.getElementById("routeDiv").style.display = "initial";
  time = convertSeconds(result.totalTime);
  km = result.totalDistance;
  icon=(type=="Voiture")?'<i class="fas fa-car">':'<i class="fas fa-walking"></i>';
  ht = '<h3 class="route-response">'+  icon + "  "+time + "  "+ km +'</h3>';
  document.getElementById("routeInfo").innerHTML = ht;
  tab = new Array(result.routeGeometry.coordinates.length);
  tab = result.routeGeometry;
  //var animals = ['ant', 'bison', 'camel', 'duck', 'elephant'];
//   tab.coordinates.reverse();
//   for (var i = 0; i < 2; i++) {
// tab.coordinates.pop();
//
//   }
//   tab.coordinates.reverse();
//    // tab.coordinates.slice(1);

  layerRoute = L.geoJson(tab);
  layerRoute.addTo(map);
  storeDataR = [ht , result];

}

var convertSeconds = function(sec) {
          var hrs = Math.floor(sec / 3600);
          var min = Math.floor((sec - (hrs * 3600)) / 60);
          var seconds = sec - (hrs * 3600) - (min * 60);

          var result = (hrs);
          result += ":" + (min < 10 ? "0" + min : min);
          return result;
}

function getRouteDetails(sD) {
  console.log("HERE");
  data = sD[1].routeInstructions;
  console.log(sD[0]);
  var table = document.getElementById("routeDetails");
  for (var i = data.length-1 ; i >=0 ; i--) {
    row = table.insertRow(0);
    cell1 = row.insertCell(0);
    cell2 = row.insertCell(1);
    cell2.innerHTML = data[i].distance ;
    cell1.innerHTML = data[i].instruction;
  }
  document.getElementById("caption").innerHTML = sD[0];

}

function clear() {
  $("#routeDetails tr").remove();
}

function startRouting() {
  console.log("startRouting");
  userPoint.on("move ",function () {
  calcuateRoute(userPoint.getLatLng(),destLat,destLng,mode,type);
  })
}



// function startRouting() {
//   console.log("startRouting "+userLoc.lat+" , "+userLoc.lng+" // "+latDest+" , "+ lngDest );
//   L.Routing.control({
//   waypoints: [
//     L.latLng(userLoc.lat,userLoc.lng),
//     L.latLng(latDest, lngDest),
//   ],
//   serviceUrl: 'https://router.project-osrm.org/viaroute'
// }).addTo(map);
// }
